<div class="wrap">
  <h1><?php echo $theme?'Thema bearbeiten':'Neues Thema'; ?></h1>
  <form method="post">
    <?php
      wp_nonce_field('ctzen_save_theme');
      if ($theme) echo '<input type="hidden" name="id" value="'.intval($theme->id).'" />';
    ?>
    <table class="form-table">
      <!-- Titel, Parent, Reihenfolge, Datum wie zuvor... -->
      <tr>
        <th><label for="description">Beschreibung (HTML)</label></th>
        <td>
          <select id="desc-versions">
            <?php foreach($desc_versions as $v): ?>
            <option value="<?php echo $v->vid; ?>">
              <?php echo date('Y-m-d H:i',strtotime($v->created_at)).' – User#'.$v->author_id; ?>
            </option>
            <?php endforeach; ?>
          </select><br>
          <textarea name="description" id="description" class="large-text" rows="5"><?php echo esc_textarea($current['description']); ?></textarea>
        </td>
      </tr>
      <tr>
        <th><label for="opinion">Meinung (HTML)</label></th>
        <td>
          <select id="op-versions">
            <?php foreach($op_versions as $v): ?>
            <option value="<?php echo $v->vid; ?>">
              <?php echo date('Y-m-d H:i',strtotime($v->created_at)).' – User#'.$v->author_id; ?>
            </option>
            <?php endforeach; ?>
          </select><br>
          <textarea name="opinion" id="opinion" class="large-text" rows="5"><?php echo esc_textarea($current['opinion']); ?></textarea>
        </td>
      </tr>
      <tr>
        <th>Aktuelles</th>
        <td>
          <select id="akt-versions">
            <?php foreach($akt_versions as $v): ?>
            <option value="<?php echo $v->vid; ?>">
              <?php echo date('Y-m-d H:i',strtotime($v->created_at)).' – User#'.$v->author_id; ?>
            </option>
            <?php endforeach; ?>
          </select>
          <div id="aktuelles-container">
            <?php foreach($current['aktuelles'] as $i => $n): ?>
            <div class="ctz-news-row">
              <input type="date" name="news[<?php echo $i;?>][date]" value="<?php echo esc_attr($n['date']);?>">
              <textarea name="news[<?php echo $i;?>][content]" rows="2"><?php echo esc_textarea($n['content']);?></textarea>
              <a href="#" class="ctz-remove-news">Entfernen</a>
            </div>
            <?php endforeach;?>
          </div>
          <p><button id="ctz-add-news" class="button">News hinzufügen</button></p>
        </td>
      </tr>
    </table>
    <p><button type="submit" name="action" value="save" class="button button-primary">Speichern</button></p>
  </form>
</div>
